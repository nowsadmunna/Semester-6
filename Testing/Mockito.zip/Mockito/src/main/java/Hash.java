public class Hash {
    public String hash(String password) {
        return password+"123";
    }
}
